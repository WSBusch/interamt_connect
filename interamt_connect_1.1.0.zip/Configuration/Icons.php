<?php

return [
    'interamt_connect-plugin-connector' => [
        'provider' => \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
        'source' => 'EXT:interamt_connect/Resources/Public/Icons/user_plugin_connector.svg'
    ],
];
